#ItemZone Classes
class Items:
    def __init__(self, name, zone, type, description, imageLink):
        self.name = name
        self.zone = zone
        self.type = type
        self.description = description
        self.imageLink = imageLink

#Objective items        
Syringe = Items(
            name="Syringe",
            zone="City",
            type="Objective",
            description="",
            imageLink="images/Items/Syringe.png",
            )

Cactus_Juice = Items(
            name="Cactus Juice",
            zone="Desert",
            type="Objective",
            description="",
            imageLink="images/Items/Cactus Juice.png",
            )

Snowberries = Items(
            name="Snowberries",
            zone="Snow",
            type="Objective",
            description="",
            imageLink="images/Items/Snowberries.png",
            )

Herbs = Items(
            name="Herbs",
            zone="Forest",
            type="Objective",
            description="",
            imageLink="images/Items/Herbs.png",
            )

class ItemsRec:
    def __init__(self, name, zone, type, recovery, imageLink):
        self.name = name
        self.zone = zone
        self.type = type
        self.recovery = recovery
        self.imageLink = imageLink

#Recovery Items
Energy_Drink = ItemsRec(
            name="Energy Drink",
            zone="City",
            type="Recovery",
            recovery=2,
            imageLink="images/Items/Energy Drink.png",
            )

Water_Bottle = ItemsRec(
            name="Water Bottle",
            zone="Desert",
            type="Recovery",
            recovery=2,
            imageLink="images/Items/Water Bottle.png",
            )

Roasted_Meat = ItemsRec(
            name="Roasted Meat",
            zone="Snow",
            type="Recovery",
            recovery=2,
            imageLink="images/Items/Roasted Meat.png",
            )

Fruit = ItemsRec(
            name="Fruit",
            zone="Forest",
            type="Recovery",
            recovery=2,
            imageLink="images/Items/Fruit.png",
            )

class ItemsWep:
    def __init__(self, name, zone, type, damage, imageLink):
        self.name = name
        self.zone = zone
        self.type = type
        self.damage = damage
        self.imageLink = imageLink

#City Weapons
Demolition_Hammer = ItemsWep(
            name="Demolition Hammer",
            zone="City",
            type="Weapon",
            damage=3,
            imageLink="images/Items/Demolition Hammer.png",
            )

Spade = ItemsWep(
            name="Spade",
            zone="City",
            type="Weapon",
            damage=2,
            imageLink="images/Items/Spade.png",
            )

#Desert Weapons
Spear = ItemsWep(
            name="Spear",
            zone="Desert",
            type="Weapon",
            damage=2,
            imageLink="images/Items/Spear.png",
            )

Pharaoh_Scepter = ItemsWep(
            name="Pharaoh Scepter",
            zone="Desert",
            type="Weapon",
            damage=3,
            imageLink="images/Items/Pharaoh Scepter.png",
            )

#Snow Weapons
Climbing_Pick = ItemsWep(
            name="Climbing Pick",
            zone="Snow",
            type="Weapon",
            damage=2,
            imageLink="images/Items/Climbing Pick.png",
            )

Big_Branch = ItemsWep(
            name="Big Branch",
            zone="Snow",
            type="Weapon",
            damage=3,
            imageLink="images/Items/Big Branch.png",
            )

#Forest items
Axe = ItemsWep(
            name="Axe",
            zone="Forest",
            type="Weapon",
            damage=2,
            imageLink="images/Items/Axe.png",
            )

Chainsaw = ItemsWep(
            name="Chainsaw",
            zone="Forest",
            type="Weapon",
            damage=3,
            imageLink="images/Items/Chainsaw.png",
            )

class ItemsEq:
    def __init__(self, name, zone, type, danger, hp, speed, imageLink):
        self.name = name
        self.zone = zone
        self.type = type
        self.danger = danger
        self.hp = hp
        self.speed = speed
        self.imageLink = imageLink

#City Equips
Hardhat = ItemsEq(
            name="Hardhat",
            zone="City",
            type="Equip",
            danger=0,
            hp=2,
            speed=0,
            imageLink="images/Items/Hardhat.png",
            )

Nikes = ItemsEq(
            name="Nikes",
            zone="City",
            type="Equip",
            danger=0,
            hp=0,
            speed=1,
            imageLink="images/Items/Nikes.png",
            )

#Desert Equips
Pharaoh_Mask = ItemsEq(
            name="Pharaoh Mask",
            zone="Desert",
            type="Equip",
            danger=0,
            hp=3,
            speed=0,
            imageLink="images/Items/Pharaoh Mask.png",
            )        

Shu_Amulet = ItemsEq(
            name="Shu Amulet",
            zone="Desert",
            type="Equip",
            danger=0,
            hp=0,
            speed=1,
            imageLink="images/Items/Shu Amulet.png",
            )

#Snow Equips
Jacket = ItemsEq(
            name="Jacket",
            zone="Snow",
            type="Equip",
            danger=0,
            hp=2,
            speed=0,
            imageLink="images/Items/Jacket.png",
            )        

Furry_Armor = ItemsEq(
            name="Furry Armor",
            zone="Snow",
            type="Equip",
            danger=0,
            hp=3,
            speed=0,
            imageLink="images/Items/Furry Armor.png",
            )

#Forest Equips
Windbreaker = ItemsEq(
            name="Windbreaker",
            zone="Snow",
            type="Equip",
            danger=0,
            hp=2,
            speed=0,
            imageLink="images/Items/Windbreaker.png",
            )        

Ghillie_Suit = ItemsEq(
            name="Ghillie Suit",
            zone="Forest",
            type="Equip",
            danger=-1,
            hp=1,
            speed=0,
            imageLink="images/Items/Ghillie Suit.png",
            )


##########################################################################

type = ""

# City Cards randomizer

CItems = [Syringe, Syringe, Syringe, Syringe, Energy_Drink, Energy_Drink, Energy_Drink, 
          Hardhat, Hardhat, Nikes, Spade, Spade, Demolition_Hammer]
FItems = [Herbs, Herbs, Herbs, Herbs, Fruit, Fruit, Fruit, 
          Windbreaker, Windbreaker, Ghillie_Suit, Axe, Axe, Chainsaw]
DItems = [Cactus_Juice, Cactus_Juice, Cactus_Juice, Cactus_Juice, Water_Bottle, Water_Bottle, Water_Bottle, 
          Shu_Amulet, Shu_Amulet, Pharaoh_Mask, Spear, Spear, Pharaoh_Scepter]
SItems = [Snowberries, Snowberries, Snowberries, Snowberries, Roasted_Meat, Roasted_Meat, Roasted_Meat, 
          Jacket, Jacket, Furry_Armor, Climbing_Pick, Climbing_Pick, Big_Branch]

zones = [CItems, FItems, DItems, SItems]

CItemlist = [Syringe, Energy_Drink, Hardhat, Nikes, Spade, Demolition_Hammer]
FItemlist = [Herbs, Fruit, Windbreaker, Ghillie_Suit, Axe, Chainsaw]
DItemlist = [Cactus_Juice, Water_Bottle, Shu_Amulet, Pharaoh_Mask, Spear, Pharaoh_Scepter]
SItemlist = [Snowberries, Roasted_Meat, Jacket, Furry_Armor, Climbing_Pick, Big_Branch]

Itemlist = [CItemlist, FItemlist, DItemlist, SItemlist]


def ItemPicker(x):
    global ItemResult
    global type
    global itemPow
    global itemRec
    global itemHP
    global itemDan
    global itemSpd
    global result
    global zone
    global img
    
    if len(zones[x]) > 0:
        rand = int(random(1,len(zones[x])+1))  #randomizer, also makes it an integer
        print(rand)    #Prints random number

        if rand <= zones[x].count(Itemlist[x][0]):  #If 4 or less, Syringe
            ItemResult = Itemlist[x][0]
        
        elif rand <= zones[x].count(Itemlist[x][0]) + zones[x].count(Itemlist[x][1]):  #If 7 or less, Energy Drink
            ItemResult = Itemlist[x][1]
        
        elif rand <= (zones[x].count(Itemlist[x][0]) + zones[x].count(Itemlist[x][1]) +
            zones[x].count(Itemlist[x][2])):  #If 9 or less, Hard Hat
            ItemResult = Itemlist[x][2]
        
        elif rand <= (zones[x].count(Itemlist[x][0]) + zones[x].count(Itemlist[x][1]) +
            zones[x].count(Itemlist[x][2]) + zones[x].count(Itemlist[x][3])):  #If 10 or less, Nikes
            ItemResult = Itemlist[x][3]
        
        elif rand <= (zones[x].count(Itemlist[x][0]) + zones[x].count(Itemlist[x][1]) +
            zones[x].count(Itemlist[x][2]) + zones[x].count(Itemlist[x][3]) + zones[x].count(Itemlist[x][4])):  #IF 12 or less, Spade
            ItemResult = Itemlist[x][4]
    
        else:  #Else(13 or more), Demolition Hammer
            ItemResult = Itemlist[x][5]

        z = []
        for y in zones[x]:
            z.append(y.name)
        zones[x].remove(ItemResult)
        img = loadImage(ItemResult.imageLink)  #Loads the image
        type = ItemResult.type
        result = ItemResult.name
        zone = ItemResult.zone
        if type == "Recovery":
            itemRec = ItemResult.recovery
        elif type == "Weapon":
            itemPow = ItemResult.damage
        elif type == "Equip":
            itemHP = ItemResult.hp
            itemSpd = ItemResult.speed
            itemDan = ItemResult.danger
    else:
        empty = True
        if empty == True:
            zones[x] = []
            print("empty")
            textSize(32)
            fill(0,0,0)
            text("This zone is empty", 500, 300)
            noFill()
