import Stats

def PickPlayer(clicked):
    imgbut = loadImage("images/menu/sign.png")
    for x in range(1, len(Stats.playerList)):
        textSize(32) 
        Stats.playerList[x]
        fill(0)
        text(Stats.playerList[x].name, 230*x, 300)
        image(imgbut, 230*x - 30, 320, 180, 100)
        fill(255)
        if clicked == "Attack":
            text(clicked, 230*x + 5, 375)
        elif clicked == "WorkTogether":
            if Stats.playerList[x] in Stats.playerList[0].WorkTog:   #If already working together
                textSize(24)
                text("Stop working", 230*x -15, 360)
                text("together", 230*x -15, 390)
            else:   #If not working together
                textSize(24)
                text("Work", 230*x + 5, 360)
                text("Together", 230*x + 5, 390)
            
