##########################################################

#ZombieEncounter Classes
class Zombies:
    def __init__(self, name, hp, power, imageLink, encounter):
        self.name = name
        self.hp = hp
        self.power = power
        self.imageLink = imageLink
        self.encounter = encounter
        
Zombie = Zombies(
            name="Zombie",
            hp=3,
            power=1,
            imageLink="images/Encounter/Zombie.png",
            encounter = True
            )
        
Hulking_Zombie = Zombies(
            name="Hulking Zombie",
            hp=5,
            power=3,
            imageLink="images/Encounter/Hulking Zombie.png",
            encounter = True
            )
        
Horde = Zombies(
            name="Horde",
            hp=3,
            power=9001,
            imageLink="images/Encounter/Horde.png",
            encounter = True
            )
        
class Encounter:
    def __init__(self, name, imageLink, encounter):
        self.name = name
        self.imageLink = imageLink
        self.encounter = encounter

No_Encounter = Encounter(
            name="No Encounter",
            imageLink="images/Encounter/No Encounter.png",
            encounter = False
            )
        
Evaded_Encounter = Encounter(
            name="Evaded Encounter",
            imageLink="images/Encounter/Evaded Encounter.png",
            encounter = False
            )

########################################################

# 27 Zombie
# 2 Hulking Zombie
# 1 Horde

# 3 Evaded Encounter
# 3 No Counter

#########################################################

encounterResult = False
monsterPower = 0
monsterHP = 0

def encounter():  #Monster Encounter Function
    global encounterResult
    global monsterPower
    global monsterHP

    rand = int(random(1,36+1))  #randomizer, also makes it an integer
    print(rand)    #Prints random number

    if rand <= 27:  #If 27 or less, zombie
        monsterResult = Zombie
        
    elif rand <=29:  #If 29 or less, hulking zombie
        monsterResult = Hulking_Zombie
        
    elif rand <= 30:  #If 30 or less, horde
        monsterResult = Horde
        
    elif rand <= 33:  #If 33 or less, evaded encounter
        monsterResult = Evaded_Encounter
        
    else:  #Else(34 or more), no encounter
        monsterResult = No_Encounter
        
    img = loadImage(monsterResult.imageLink)  #Loads the image
    encounterResult = monsterResult.encounter  #encounterResult is True/False
    if encounterResult == True:
        monsterPower = monsterResult.power
        monsterHP = monsterResult.hp
    else:
        monsterPower = 0
        monsterHP = 0

    print(monsterResult.name)
    image(img, 0, 0, 490, 694) #Show card image
