def manualselect():
    imgselect = loadImage("images/menu/sign.png")
    image(imgselect, 25, 25, 200, 50)
    image(imgselect, 235, 25, 120, 50)
    image(imgselect, 365, 25, 185, 50)
    image(imgselect, 560, 25, 75, 50)
    image(imgselect, 645, 25, 115, 50)
    image(imgselect, 12, 100, 762, 5)
    textSize(20)
    fill(255, 255, 255)
    text("General gameplay", 35, 55)
    text("Character", 245, 55)
    text("Encounter types", 375, 55)
    text("Items", 570, 55)
    text("Objective", 655, 55)
    
def gentab():
    fill(0, 0, 0)
    textSize(18)
    text("Rules of movement", 25, 325)
    text("Rules of encounters", 25, 425)
    text("Rules of combat", 25, 550)
    textSize(16)
    text("In order to make your way through the safezone you will have to traverse a difficult path with additional challenges.", 25, 150)
    text("Each player rolls the dice at the start of the game. The highest roll decides who starts and the turns move clock-wise.", 25, 175)
    text("Everyone starts with 10HP, 1 Power and 1 Speed.", 25, 200)
    text("The map is divided into four districts, with each having their owns set of items.", 25, 225)
    text("There are two spots in every district on which a card can be drawn.", 25, 250)
    text("A player cannot draw a card from the same spot twice in a row. They have to move to a different spot first.", 25, 275)
    text("The game moves at a pace of 1 step at each turn, given that they aren't attacked. This step can be in any direction.", 25, 350)
    text("Speed affects the amount of steps you can take, but only takes effect once every 3 turns and if you don't encounter a zombie.", 25, 375)
    text("A dice is rolled before a player takes a step. This dice determines whether or not that player has to draw an encounter card.", 25, 450)
    text("'Danger' affects the dice roll. Every point in Danger increases the height of your required roll to avoid drawing a card.", 25, 475)
    text("Rolls are dependent on the amount of player participating in the game. Every extra player increases the Danger by 1.", 25, 500)
    text("In a player versus zombie scenario, the player goes first.", 25, 575)
    text("In a player versus player scenario, the player that moves on top of the other goes first.", 25, 600)
    text("Combat has to end before the player can take another move.", 25, 625)
    text("Players can end combat with each other if both sides agree.", 25, 650)
    text("Combat against zombies cannot be ignored. Combat ends when either side is defeated in this case.", 25, 675)
    

def charview():
    fill(0, 0, 0)
    textSize(16)
    text("Down below is a copy of your character.", 25, 150)
    text("As you progress in the game, it will update itself accordingly.", 25, 175)
    text("Any stat changes upon receiving a card will be shown in the bottom as Power, Speed or Danger.", 25, 200)
    text("HP loss after an encounter or gain after getting a card for it is updated as well.", 25, 225)
    text("You can hover over the image to view some tooltips.", 25, 250)
    

def encounterview():
    
    imgback = loadImage("images/menu/sign.png")
    image(imgback, 100, 225, 140, 35)
    image(imgback, 245, 225, 120, 35)
    image(imgback, 370, 225, 60, 35)
    image(imgback, 100, 265, 70, 35)
    image(imgback, 175, 265, 110, 35)
    image(imgback, 290, 265, 50, 35)
    
    textSize(14)
    fill(255, 255, 255)
    text("Common zombie", 110, 245)
    text("Hulking threat", 255, 245)
    text("Horde", 380, 245)
    text("Evasion", 110, 285)
    text("No encounter", 185, 285)
    text("Hide", 300, 285)
    
    textSize(16)
    fill(0, 0, 0)
    text("While playing the game there's a chance to face an encounter with each step you take.", 25, 150)
    text("These encounters vary in strength and can provide some serious harm or even death in rare cases.", 25, 175)
    text("You can get a glimpse here of the various encounters that may stand in your way or lack thereof.", 25, 200)
    noFill()

def itemview():
        
    imgback = loadImage("images/menu/sign.png")
    image(imgback, 550, 250, 70, 40)
    image(imgback, 550, 295, 70, 40)
    image(imgback, 625, 250, 70, 40)
    image(imgback, 625, 295, 70, 40)
    image(imgback, 548, 340, 149, 40)
    textSize(14)
    fill(255, 255, 255)
    text("City", 560, 275)
    text("Desert", 560, 320)
    text("Forest", 635, 275)
    text("Snow", 635, 320)
    text("Hide", 600, 365)

    textSize(16)
    fill(0, 0, 0)
    text("Along the paths are certain spots which will let you draw an item.", 25, 150)
    text("These items will aid you on your way to the objective.", 25, 175)
    text("Every district has its own set of items and you can draw duplicates in which case you'll only receive the effect of one.", 25, 200)
    text("Click on the buttons below to get a preview of a random item for each district.", 25, 225)    
    noFill()


def objectview():
    textSize(16)
    fill(0, 0, 0)
    text("The first player to reach the safezone with all prequisites is the winner.", 25, 150)
    text("In order to get there you must venture through all districts and collect the required items.", 25, 175)
    text("Once these sets of items have been collected, head over to the safezone or you can always", 25, 200)
    text("feel free to delay your opponents on their way there.", 25, 225)
    text("Hover over various parts of the map below to learn more about its structure.", 25, 250)


def szone():
        fill(255, 252, 119)
        rect(265, 350, 355, 60)
        fill(0, 0, 0)
        textSize(14)
        text("This is the final location to reach in order to finish.", 270, 365)
        text("Be aware that you must have an objective item", 270, 385)
        text("from each district in order to be granted access.", 270, 405)

def cstart():
        fill(255, 252, 119)
        rect(80, 300, 310, 20)
        fill(0, 0, 0)
        textSize(14)
        text("This is the starting zone for the city district.", 85, 315)

def dstart(): 
        fill(255, 252, 119)
        rect(80, 610, 330, 20)
        fill(0, 0, 0)
        textSize(14)
        text("This is the starting zone for the desert district.", 85, 625)
        
def sstart():
        fill(255, 252, 119)
        rect(250, 300, 320, 20)
        fill(0, 0, 0)
        textSize(14)
        text("This is the starting zone for the snow district.", 255, 315)

def fstart(): 
        fill(255, 252, 119)
        rect(250, 610, 330, 20)
        fill(0, 0, 0)
        textSize(14)
        text("This is the starting zone for the forest district.", 255, 625)

def itemspot():
        fill(255, 252, 119)
        rect(150, 450, 370, 60)
        fill(0, 0, 0)
        textSize(14)
        text("This is one of the various spots on which you can get", 155, 465)
        text("a random card from that specific district's deck.", 155, 485)
        text("Each district contains 2 of these locations.", 155, 505)
        
def chartip():
        fill(255, 252, 119)
        rect(90, 300, 160, 20)
        fill(0, 0, 0)
        textSize(14)
        text("This is your character.", 95, 315)
        
def itemtip():
        fill(255, 252, 119)
        rect(60, 400, 230, 140)
        fill(0, 0, 0)
        textSize(14)
        text("These slots give an indication", 65, 415)
        text("on the type of items that you", 65, 435)
        text("can receive.", 65, 455)
        text("The slots will fill up by themself", 65, 495)
        text("when you have received the", 65, 515)
        text("appropriate items for them.", 65, 535)
        
def stattip():
        fill(255, 252, 119)
        rect(150, 620, 280, 40)
        fill(0, 0, 0)
        textSize(14)
        text("Information relevant to the state your", 155, 635)
        text("character is in will be shown in this box.", 155, 655)
