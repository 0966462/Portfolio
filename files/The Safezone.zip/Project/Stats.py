import ItemCards
import ZombieEncounter

class Player:
    def __init__(self, name, speed, danger, hp, maxhp, power, sinv, inv, hasW, hasH, hasSp, hasS, hasEq, SZone, FZone, DZone, UZone, finish, WorkTog):
        self.name = name
        self.speed = speed
        self.danger = danger
        self.hp = hp
        self.maxhp = maxhp
        self.power = power
        self.sinv = sinv
        self.inv = inv
        self.hasW = hasW
        self.hasH = hasH
        self.hasSp = hasSp
        self.hasS = hasS
        self.hasEq = hasEq
        self.SZone = SZone
        self.FZone = FZone
        self.DZone = DZone
        self.UZone = UZone
        self.finish = finish
        self.WorkTog = WorkTog
        
Player_1 = Player(
                name = "Player 1",
                speed = 0,
                danger = 0,
                hp = 10,
                maxhp = 10,
                power = 0,
                sinv=[],
                inv=[],
                hasW=False,
                hasH=False,
                hasSp=False,
                hasS=False,
                hasEq=False,
                SZone = False,
                FZone = False,
                DZone = False,
                UZone = False,
                finish = False,
                WorkTog = []
                )

Player_2 = Player(
                name = "Player 2",
                speed = 0,
                danger = 0,
                hp = 10,
                maxhp = 10,
                power = 0,
                sinv=[],
                inv=[],
                hasW=False,
                hasH=False,
                hasSp=False,
                hasS=False,
                hasEq=False,
                SZone = False,
                FZone = False,
                DZone = False,
                UZone = False,
                finish = False,
                WorkTog = []
                )

Player_3 = Player(
                name = "Player 3",
                speed = 0,
                danger = 0,
                hp = 10,
                maxhp = 10,
                power = 0,
                sinv=[],
                inv=[],
                hasW=False,
                hasH=False,
                hasSp=False,
                hasS=False,
                hasEq=False,
                SZone = False,
                FZone = False,
                DZone = False,
                UZone = False,
                finish = False,
                WorkTog = []
                )

Player_4 = Player(
                name = "Player 4",
                speed = 0,
                danger = 0,
                hp = 10,
                maxhp = 10,
                power = 0,
                sinv=[],
                inv=[],
                hasW=False,
                hasH=False,
                hasSp=False,
                hasS=False,
                hasEq=False,
                SZone = False,
                FZone = False,
                DZone = False,
                UZone = False,
                finish = False,
                WorkTog = []
                )

playerList = [Player_1]
pick = False
        
def playerPick():
    global playerList
    global pick
    if mousePressed and mouseX < 355 and mouseX > 285 and mouseY < 310 and mouseY > 240: #Mouseclicks 2 Players
        playerList = [Player_1,Player_2]
        pick = True
    if mousePressed and mouseX < 1005 and mouseX > 935 and mouseY < 310 and mouseY > 240:
        playerList = [Player_1,Player_2,Player_3]
        pick = True
    if mousePressed and mouseX < 680 and mouseX > 610 and mouseY < 510 and mouseY > 440:
        playerList = [Player_1,Player_2,Player_3,Player_4]
        pick = True
          
def buttons():
    global playerList
    
    textSize(32)
    rect(750, 50, 100, 50)
    triangle(800, 55, 825, 90, 775, 90)
    rect(750, 125, 100, 200)
    if playerList[0].hp > playerList[0].maxhp / 2:
        fill(0,255,0)
    else:
        fill(255,0,0)
    text("%d HP" % playerList[0].hp, 755, 250)
    noFill()
    rect(750, 350, 100, 50)
    triangle(800, 390, 825, 355, 775, 355)

def recover():
    global playerList

    Recovery = ItemCards.itemRec
    if playerList[0].hp < playerList[0].maxhp:
        playerList[0].hp += Recovery
        if playerList[0].hp > playerList[0].maxhp:
            playerList[0].hp = playerList[0].maxhp

def useHeal():
    global playerList
    
    inv = playerList[0].inv
    Recovery = 0
    for i in inv:
        changePos = playerList[0].inv.pop(0)
        playerList[0].inv.append(changePos)
        if playerList[0].inv[0] == "Roasted Meat" or playerList[0].inv[0] == "Water Bottle" or playerList[0].inv[0] == "Fruit" or playerList[0].inv[0] == "Energy Drink":
            Recovery = ItemCards.itemRec
            if playerList[0].hp < playerList[0].maxhp:
                playerList[0].hp += Recovery
                if playerList[0].hp > playerList[0].maxhp:
                    playerList[0].hp = playerList[0].maxhp
                for i in inv:
                    if playerList[0].inv[0] == "Roasted Meat" or playerList[0].inv[0] == "Water Bottle" or playerList[0].inv[0] == "Fruit" or playerList[0].inv[0] == "Energy Drink":
                        playerList[0].inv.remove(playerList[0].inv[0])
                        if playerList[0].hp < playerList[0].maxhp:
                            playerList[0].hp += Recovery
                        if playerList[0].hp > playerList[0].maxhp:
                            playerList[0].hp = playerList[0].maxhp
                        break
                    else:
                        changePos = playerList[0].inv.pop(0)
                        playerList[0].inv.append(changePos)
            else:
                print("Health is full!")
        else:
            print("No recovery items!")
    
        
def damage():
    global playerList
    
    HealthLoss = ZombieEncounter.monsterPower
    if HealthLoss > 0 and playerList[0].hp > 0:
        playerList[0].hp -= HealthLoss
        if playerList[0].hp <= 0:
            playerList[0].hp = 0
    delay(100)

def itemAdd():
    global playerList
    
    iAdd = ItemCards.ItemResult
    siAdd = ItemCards.result
    playerList[0].inv.append(iAdd)
    playerList[0].sinv.append(siAdd)

def progress():
    global playerList
    global SZone
    global FZone
    global DZone
    global UZone
    global finish
    
    iAdd = ItemCards.ItemResult
    siAdd = ItemCards.result
    playerList[0].inv.remove(iAdd)
    playerList[0].sinv.remove(siAdd)
    if playerList[0].SZone == False or playerList[0].FZone == False or playerList[0].DZone == False or playerList[0].UZone == False:
        if siAdd == "Snowberries" and playerList[0].SZone == False:
            playerList[0].SZone = True
            playerList[0].inv.append(ItemCards.ItemResult)
            playerList[0].sinv.append(siAdd)
        elif siAdd == "Snowberries" and playerList[0].SZone == True:
            ItemCards.SItems.append(ItemCards.ItemResult)
            textSize(32)
            fill(0,0,0)
            text("You dont need this anymore", 500,500)
            noFill()
            
        elif siAdd == "Herbs" and playerList[0].FZone == False:
            playerList[0].FZone = True
            playerList[0].inv.append(ItemCards.ItemResult)
            playerList[0].sinv.append(siAdd)
        elif siAdd == "Herbs" and playerList[0].FZone == True:
            ItemCards.FItems.append(ItemCards.ItemResult)
            textSize(32)
            fill(0,0,0)
            text("You dont need this anymore", 500,500)
            noFill()
            
        elif siAdd == "Cactus Juice" and playerList[0].DZone == False:
            playerList[0].DZone = True
            playerList[0].inv.append(ItemCards.ItemResult)
            playerList[0].sinv.append(siAdd)
        elif siAdd == "Cactus Juice" and playerList[0].DZone == True:
            ItemCards.DItems.append(ItemCards.ItemResult)
            textSize(32)
            fill(0,0,0)
            text("You dont need this anymore", 500,500)
            noFill()
            
        elif siAdd == "Syringe" and playerList[0].UZone == False:
            playerList[0].UZone = True
            playerList[0].inv.append(ItemCards.ItemResult)
            playerList[0].sinv.append(siAdd)
        elif siAdd == "Syringe" and playerList[0].UZone == True:
            ItemCards.CItems.append(ItemCards.ItemResult)
            textSize(32)
            fill(0,0,0)
            text("You dont need this anymore", 500,500)
            noFill()

    if playerList[0].SZone == True and playerList[0].FZone == True and playerList[0].DZone == True and playerList[0].UZone == True:
        print("You have everything to enter the Safe-zone!")
        playerList[0].finish = True
        
    

def playerP():
    global power
    global hasW
        
    increaseP = ItemCards.itemPow
    type = ItemCards.zone
    siAdd = ItemCards.result
    playerList[0].hasW = True
    if playerList[0].power < increaseP:
        playerList[0].power = increaseP
    elif playerList[0].power >= increaseP:
        if type == "City":
            ItemCards.CItems.append(ItemCards.ItemResult)
        elif type == "Forest":
            ItemCards.FItems.append(ItemCards.ItemResult)
        elif type == "Desert":
            ItemCards.DItems.append(ItemCards.ItemResult)
        elif type == "Snow":
            ItemCards.SItems.append(ItemCards.ItemResult)
        if playerList[0].power > increaseP:
            textSize(32)
            fill(0,0,0)
            text("You already have a better weapon!", 500,500)
            noFill()
            playerList[0].inv.remove(ItemCards.ItemResult)
            playerList[0].sinv.remove(siAdd)
        elif playerList[0].power == increaseP:
            textSize(32)
            fill(0,0,0)
            text("You dont need this one", 500,500)
            noFill()
            playerList[0].inv.remove(ItemCards.ItemResult)
            playerList[0].sinv.remove(siAdd)
        
def addHealth():
    global playerList
    global hasH
    global hasEq
    global hasSp
    global hasS
    
    itemHP = ItemCards.itemHP
    itemDan = ItemCards.itemDan
    itemSpd = ItemCards.itemSpd
    playerList[0].maxhp += itemHP
    playerList[0].hp += itemHP
    playerList[0].danger += itemDan
    itemName = ItemCards.result
    if itemName == "Furry Armor" or itemName == "Jacket" or itemName == "Windbreaker":
        playerList[0].hasEq = True
    if itemName == "Ghillie Suit":
        playerList[0].hasSp = True
    if itemName == "Hardhat" or itemName == "Pharaoh Mask":
        playerList[0].hasH = True
    if itemName == "Nikes" or itemName == "Shu Amulet":
        playerList[0].hasS = True
        
    
def middle():
    global hp
    global maxhp
    global speed
    global danger
    global power
    
    textSize(32)
    if playerList[0].hp > playerList[0].maxhp / 2:
        fill(0,255,0)
    else:
        fill(255,0,0)
    text("%d" % playerList[0].hp, 250, 550) #HP display
    text("/ %d HP" % playerList[0].maxhp, 300, 550)
    noFill()
    fill(100,100,255)
    text("%d Speed" % playerList[0].speed, 250, 600) #Speed display
    noFill()
    fill(125,0,0)
    text("%d Power" % playerList[0].power, 450, 550) #Power display
    noFill()
    fill(0,0,0)
    text("%d Danger" % playerList[0].danger, 450, 600) #Danger display
    noFill()
    
def stats():
    invimg = loadImage("/images/Inventory.png")
    image(invimg, 100, 100, 602, 542)
    
def end_turn():
    global playerList
    
    changePos = playerList.pop(0)
    playerList.append(changePos)

    clear()
    
def equipLines():
    global playerList
    
    if playerList[0].hasH == True: #Shows in Health Tab that the player has a helmet on
        strokeWeight(10)
        stroke(255,223,0)
        rect(462,122,98,75)
        noFill()
        strokeWeight(1)
        stroke(0,0,0)
    if playerList[0].hasEq == True: #Shows in Health Tab that the player has equipment on
        strokeWeight(10)
        stroke(255,223,0)
        rect(462,218,98,75)
        noFill()
        strokeWeight(1)
        stroke(0,0,0)
    if playerList[0].hasS == True:
        strokeWeight(10)
        stroke(255,223,0)
        rect(462,316,98,75)
        noFill()
        strokeWeight(1)
        stroke(0,0,0)
    if playerList[0].hasW == True:
        strokeWeight(10)
        stroke(255,223,0)
        rect(462,414,98,75)
        noFill()
        strokeWeight(1)
        stroke(0,0,0)
    if playerList[0].hasSp == True:
        strokeWeight(10)
        stroke(255,223,0)
        rect(584,262,98,75)
        noFill()
        strokeWeight(1)
        stroke(0,0,0)
    

def draw():
    stats()
    middle()
    equipLines()
